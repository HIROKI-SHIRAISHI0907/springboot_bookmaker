# -*- coding: utf-8 -*-
"""
Lambda版: 一度だけ実行する移行スクリプト。

S3の seqmap.pkl を読み込み、DynamoDB(bm_seq_counter)の各mid項目を
「まだ存在しない場合のみ」作成する。

- 既にDynamoDB側にアイテムがある場合は上書きしない
  （本番運用が新スクリプトで先に進めた最新値を壊さないため）
- そのため、何度呼び出しても安全（冪等）
- 新スクレイパー(flashscore_scraper.py)に切り替える"前"に一度だけ手動invokeする

手動実行:
    aws lambda invoke \\
      --function-name bm-seqmap-migration \\
      --cli-binary-format raw-in-base64-out \\
      --payload '{}' \\
      response.json
    cat response.json

必要なIAM権限（このLambdaの実行ロールに付与）:
    - s3:GetObject   (対象: s3://aws-s3-outputs-csv/seqmap/seqmap.pkl)
    - dynamodb:PutItem (対象: bm_seq_counter テーブル)
    - AWSLambdaBasicExecutionRole相当（CloudWatch Logs書き込み）
"""
import json
import pickle

import boto3
from botocore.exceptions import ClientError

S3_BUCKET_OUTPUTS = "aws-s3-outputs-csv"
SEQMAP_S3_KEY = "seqmap/seqmap.pkl"
SEQ_TABLE_NAME = "bm_seq_counter"
REGION = "ap-northeast-1"

s3 = boto3.client("s3", region_name=REGION)
dynamodb = boto3.resource("dynamodb", region_name=REGION)
table = dynamodb.Table(SEQ_TABLE_NAME)


def migrate() -> dict:
    try:
        obj = s3.get_object(Bucket=S3_BUCKET_OUTPUTS, Key=SEQMAP_S3_KEY)
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if code in ("NoSuchKey", "404"):
            msg = f"移行対象なし: s3://{S3_BUCKET_OUTPUTS}/{SEQMAP_S3_KEY} が見つかりません。"
            print(f"⚠️ {msg}")
            return {"status": "SKIPPED", "message": msg}
        raise

    seqmap = pickle.loads(obj["Body"].read())
    print(f"📥 loaded {len(seqmap)} entries from s3://{S3_BUCKET_OUTPUTS}/{SEQMAP_S3_KEY}")

    migrated = 0
    skipped = 0
    failed = []
    for mid, seq in seqmap.items():
        if not mid:
            continue
        try:
            table.put_item(
                Item={"mid": str(mid), "seq": int(seq)},
                ConditionExpression="attribute_not_exists(mid)",
            )
            migrated += 1
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            if code == "ConditionalCheckFailedException":
                skipped += 1
                continue
            print(f"❌ failed mid={mid} seq={seq}: {e}")
            failed.append(str(mid))
            continue

    result = {
        "status": "OK" if not failed else "PARTIAL_FAILURE",
        "total": len(seqmap),
        "migrated": migrated,
        "skipped": skipped,
        "failed_count": len(failed),
        "failed_mids": failed[:20],  # ログが肥大化しないよう先頭20件のみ
    }
    print(f"✅ 完了: {json.dumps(result, ensure_ascii=False)}")
    return result


def lambda_handler(event, context):
    result = migrate()
    return {
        "statusCode": 200 if result["status"] != "PARTIAL_FAILURE" else 500,
        "body": json.dumps(result, ensure_ascii=False),
    }
